let balance = 1000;
const balanceElement = document.getElementById('balance');
const betAmountInput = document.getElementById('betAmount');
const resultText = document.getElementById('resultText');
const diceResult = document.getElementById('diceResult');
const dice1 = document.getElementById('dice1');
const dice2 = document.getElementById('dice2');
const historyList = document.getElementById('historyList');
const diceSound = document.getElementById('diceSound');
const winSound = document.getElementById('winSound');
const loseSound = document.getElementById('loseSound');

document.getElementById('placeBet').addEventListener('click', () => {
  const betAmount = parseInt(betAmountInput.value);
  if (betAmount > balance || betAmount <= 0) {
    alert('Invalid bet amount!');
    return;
  }
  placeBet(betAmount);
});

document.getElementById('7up').addEventListener('click', () => playGame('7up'));
document.getElementById('7down').addEventListener('click', () => playGame('7down'));
document.getElementById('7').addEventListener('click', () => playGame('7'));

function placeBet(betAmount) {
  balance -= betAmount;
  balanceElement.textContent = balance;
}

function playGame(choice) {
  const betAmount = parseInt(betAmountInput.value);
  if (betAmount > balance || betAmount <= 0) {
    alert('Invalid bet amount!');
    return;
  }

  diceSound.play();

  const diceValue1 = Math.floor(Math.random() * 6) + 1;
  const diceValue2 = Math.floor(Math.random() * 6) + 1;
  const totalDiceValue = diceValue1 + diceValue2;

  diceResult.textContent = `Dice Result: ${totalDiceValue}`;
  checkResult(totalDiceValue, choice, betAmount);
}

function checkResult(totalDiceValue, choice, betAmount) {
  let result = '';
  if ((choice === '7up' && totalDiceValue > 7) || (choice === '7down' && totalDiceValue < 7) || (choice === '7' && totalDiceValue === 7)) {
    balance += betAmount * 2;
    result = 'You Win!';
    winSound.play();
  } else {
    result = 'You Lose!';
    loseSound.play();
  }
  balanceElement.textContent = balance;
  resultText.textContent = result;

  const historyItem = document.createElement('li');
  historyItem.textContent = `${choice} | Dice: ${totalDiceValue} | ${result}`;
  historyList.appendChild(historyItem);
}
